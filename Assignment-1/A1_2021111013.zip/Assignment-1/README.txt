Introduction to Software Systems (ISS)'22
Assignment - 1 -> BASH

# BHAV BERI
# 2021111013
# Section - A
# Group - 5

GitHub Repository Direct Link -> https://github.com/b-beri/ISS/tree/main/Assignment-1


~~ Special Notes regarding Scripts ~~

Q1a) Executed using ./Q1a.sh
     Deletes empty lines in the quotes.txt file inplace
     
Q1b) Executed using ./Q1b.sh
     Deletes duplicate lines in the quotes.txt file inplace
     
Q2) Executed using ./Q2.sh
    Creates new file - speech.txt - with the quotes as in required format.
    
Q3) Executed using ./Q3.sh <filename>
    Prints the required information in sequential manner(as given)
    
Q4) Executed using ./Q4.sh
		Required to give array of space-separated integers in a single line
		(Ex -> 3 1 4 2 0)
		Prints the sorted array of integers.

Q5) Executed using ./Q5.sh
		Required to give a string Input
		(Ex -> Helloo / Hello / ISS)
		Prints the output as in given format sequentially.
