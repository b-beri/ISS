Introduction to Software Systems (ISS)'22
{{ Assignment - 1 -> BASH }}

# BHAV BERI
# 2021111013
# Section - A
# Group - 5

GitHub Repository Direct Link -> https://github.com/b-beri/ISS/tree/main/Assignment-1


~~ Special Notes regarding Scripts ~~

Q1) Executed using ./q1.sh
     a) Deletes empty lines in the quotes.txt file and prints on the terminal.
     b) Deletes duplicate lines in the quotes.txt file and prints on the terminal.
     
Q2) Executed using ./q2.sh
    Creates new file - speech.txt - with the quotes as in required format, from the quotes.txt file.
    
Q3) Executed using ./q3.sh <filename>
    Prints the required information in sequential manner(as given)
    
Q4) Executed using ./q4.sh
		Required to give array of comma-separated integers in a single line.
		(Ex -> 3,1,4,2,0)
		Prints the sorted array of integers.

Q5) Executed using ./q5.sh
		Required to give a single string Input
		(Ex -> Helloo / Hello / ISS)
		Prints the output as in given format sequentially.
